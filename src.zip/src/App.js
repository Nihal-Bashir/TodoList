import React, { useState } from 'react';
import './App.css';
import REACTLOGO from './images/Notefy.png';



const TodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [newTodo, setNewTodo] = useState('');
  const [currentDateTime, setCurrentDateTime] = useState('');

  const addTodo = () => {
    if (newTodo.trim() !== '') {
      setTodos([
        ...todos,
        { id: Date.now(), text: newTodo, completed: false, dateTime: currentDateTime },
      ]);
      setNewTodo('');
      setShowForm(false);
    }
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  const toggleComplete = (id) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const openForm = () => {
    setCurrentDateTime(new Date().toLocaleString());
    setShowForm(true);
  };

  return (
    <div className="app-container">
      <div className="todos-container">
      <img src={REACTLOGO} alt=''/>
        <h1>Notefy</h1>
        <ul>
          {todos.map((todo) => (
            <li key={todo.id}>
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => toggleComplete(todo.id)}
              />
              <span
                style={{
                  textDecoration: todo.completed ? 'line-through' : 'none',
                }}
              >
                {todo.text} - {todo.dateTime}
              </span>
              <button  onClick={() => deleteTodo(todo.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>

      <button className="add-button" onClick={openForm}>
        +
      </button>

      {showForm && (
        <div className="form-popup">
          <p>{currentDateTime}</p>
          <input
            type="text"
            placeholder="Enter your todo"
            value={newTodo}
            onChange={(e) => setNewTodo(e.target.value)}
          />
          <div className='button'>
          <button onClick={addTodo}>Add Todo</button>
          <button onClick={() => setShowForm(false)}>Cancel</button>
        </div>
        </div>
      )}
    </div>
  );
};

export default TodoApp;